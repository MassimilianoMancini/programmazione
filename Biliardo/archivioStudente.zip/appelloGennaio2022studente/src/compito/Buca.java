package compito;

import java.util.Set;

import auxi.Biglia;

public class Buca {

	public Buca(Set<Biglia> imbucate) {
		//stub
		super();
	}
	
	public Set<Biglia> getImbucate() {
		//stub
		return null;
	}
}
