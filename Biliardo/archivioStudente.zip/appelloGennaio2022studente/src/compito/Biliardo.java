package compito;

import java.util.List;
import java.util.Set;

import auxi.Biglia;

public class Biliardo {

	public Biliardo() {
		//stub
	}

	public Biliardo(List<Buca> buche, Set<Biglia> tavolo) {
		//stub
	}
	
	public List<Buca> getBuche() {
		//stub
		return null;
	}

	public Set<Biglia> getTavolo() {
		//stub
		return null;
	}

	
	public boolean gameOver() {
		//stub
		return false;
	}

	public boolean pallinoImbucato() {
		//stub
		return false;
	}
	
	public void reset() {
		//stub
	}

}
