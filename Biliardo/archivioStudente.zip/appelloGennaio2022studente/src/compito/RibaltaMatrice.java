package compito;

public class RibaltaMatrice {

	public static int[][] ribalta(int[][] matrice, char[] asse) {
		//stub
		return null;
	}
}
