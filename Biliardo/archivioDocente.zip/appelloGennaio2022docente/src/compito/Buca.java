package compito;

import java.util.Set;

import auxi.Biglia;

public class Buca {
	private final Set<Biglia> imbucate;

	public Buca(Set<Biglia> imbucate) {
		super();
		this.imbucate = imbucate;
	}
	
	public Set<Biglia> getImbucate() {
		return imbucate;
	}
}
